import java.util.Date;
import java.util.UUID;

public class Patient extends Person{

    private final int Patientid;

    public Patient(String name, String surname, Date birthDate, String mobileNumber) {
        super(name, surname, birthDate, mobileNumber);
        this.Patientid = generateUniqueId();
    }

    public int getPatientid() {
        return this.Patientid;
    }

    public static int generateUniqueId() {
        UUID randomNumber = UUID.randomUUID();
        String value =""+randomNumber;
        int uid=value.hashCode();
        String filterStr=""+uid;
        value = filterStr.replaceAll("-", "");
        return Integer.parseInt(value);
    }
}
